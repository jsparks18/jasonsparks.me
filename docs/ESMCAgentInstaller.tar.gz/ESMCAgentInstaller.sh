#!/bin/sh -e
# ESET Security Management Center
# Copyright (c) 1992-2019 ESET, spol. s r.o. All Rights Reserved

cleanup_file="$(mktemp -q)"
finalize()
{
  set +e
  if test -f "$cleanup_file"
  then
    while read f
    do
      unlink "$f"
    done < "$cleanup_file"
    unlink "$cleanup_file"
  fi
}

trap 'finalize' HUP INT QUIT TERM EXIT

eraa_server_hostname="era10012.eset.scalematrix.com"
eraa_server_port="2222"
eraa_server_company_name=""
eraa_peer_cert_b64="MIIJZQIBAzCCCS8GCSqGSIb3DQEHAaCCCSAEggkcMIIJGDCCA88GCSqGSIb3DQEHBqCCA8AwggO8AgEAMIIDtQYJKoZIhvcNAQcBMBwGCiqGSIb3DQEMAQYwDgQI61wVwh+XZ+ECAggAgIIDiJblW+5gVmWfrskJNNPpIxRB5m7LzQCpCHRy0QspKpYoaebAP3Owyd8KGREK5dK5920aLg7hLkVXDFTySKOWW3MBP2W0Pm9M10OuTmzIYwt3cSIwJVTZp01nq1AQko1n7GSHMU3xwfFs8894Fqli8UJd5gWYvsH9WNYXXI80Lb17jBBp68Judf4T16W9SA2E4Jj6+XO+Mrjg/4/vqWPMIUXx5CXRLS+eqXOArkTM/coA5vr5aBxnkkmAsqiII2OYQCckua8CbUE4TKoypS3bKiEzB75jdEZaOyMdJs2L//mA01cMpibX5YRZoc5Bh+ifIsiRW00UbG+K2EHQKUjzhFn3UcNzzSsYxLoatZWY+d7dAhZFxh1hwv3Max8GFjVKYT5UR0sdO2tA8+JdGE3/XxtetmjVQCI5VqhqeV5dvitxBP+abdZB+hL5A9kTR9YppLHUSo3U04t0X3SG9rUVF3fyVcfM7S+LlDtOVyLkkz/Qu+SctCXgTCupkGcIyvgpcELQKyXuQu54O41TG81IMs8wqinAVgrElaZnbmcFmSl9YEzpWF/o5JdO+QoEZsY3/4BL0YMzZq8Xu3VEZmTSk9H5FhkmbPm80ovekvqb3iPSKMpwaXD9i73gfvjLcQt0dTnZXIe0bf+Gmrb3LC6X/4ZRBffZwW/weGDVMjDUtKUU1rnxkfxU48zcoz8KLlWQDYc41O56lIINc2cn6UDl8BrQXZPm+m36tYWJ0GhZWvI7Fuh4O8uK07owMxFid5n4WtdbQsjj0ew8iV/V32/cQQIu+8iiFS98qaFDKKquC7cA3WbSGi984As+2pkkdpbwimmiFDk1dIHI9ZoVt2oqCJG8PpLgxRIAKPp7hvMzIzotCsW9WZ+BSYkW6lOzb6gHo7QlGl1mYPOOJ3s4Bdw+s5u1VBTK5Zv/4dajiiMI0z8YdV+lyX02ddSD3P4M/nexUvI1H0EaUi2yIG8HHseD+5f5NvjxncZ3KNquVgGTFpHvBdnVA6kK6SHCqMhS+akZowLXFxn8p5iiw6HvsTMNT1PENok/w0LU6/YpTMhc52X7TnyxRTHQflMFdnxqnkZkCxHtOO7dRn6gO5CBObKwWJYUsyH6qvAbku72DJFzO+w8EIUy7W6JmtSGsKg/2ZfTyFXa4EjLEW/OMxI7GyIg//AMzt6wxh+dJvaKCoTmTaSUBEFZbvNgDccwggVBBgkqhkiG9w0BBwGgggUyBIIFLjCCBSowggUmBgsqhkiG9w0BDAoBAqCCBO4wggTqMBwGCiqGSIb3DQEMAQMwDgQIdLwbcfib0QoCAggABIIEyDwJXJNPJQ+Si9Go3IyB2GQsrxwUD6cVelqQ4mviJ39HDoUfs3x1vuIf0vzOCLJNQKWp1JysCv2vryNVzgyCGCAh0P6sz6wcgXJHc68D+wmuneikbxwbd1RHcJJqc9rzk9FpcF3Sf+3GgH8HSUzXDzLLXSsK745iM7YJkOVx/UZClMcn0dkxgYtMyzvktr8+0v9jZ1jfiiRDUm53LPidF18CDOl5rPe3CiKr8L9XKM5Qr7CBWjRNhvd/S4LX94NcLv9jPJpO7NdW8S58llMTNnfyMFBsyPncfE33gFtpEd7vMjnHoxRIKN6xn9/DM07QU1ePzTV0c4BlcakCTOxdhtdtIBJZncKnqKDZKs0W3Of8Z8HdDx/5cppTXupSn7nQle5gfygxXsBG4/XKGACR+Cq1fY4YULCTgDni0Xk3MjImHL3cIWIH/sPT+v6MqrgO1ZilFUAWRPvjJC+rDGjzX9/ZBPOPBnEvoAJ6AwWXgTE3p8DUXMO1ywWVzGOqCz39Y10z5GLi7VrKeLkAaq/ZQBr+NNh59g+8k06b88ya+pPhY/NlulXGJkByR1EBtVCtJSIfFdDYB+6BZDbG1Es8uzoeMpi/SdC/kBuqseRp6YBZ/RadxWwLKpijoUZF1XTrNtEgE8Ek0mJQss+MswrxQbQ76o3Y4/ne9rrQOH0+cTs1q9AwbpVysXfd2quzGat17lZZHLZ8lHeyYg952by20TH+USbR7Ewe8MRUKUuagtvZRSp3hmhtY5scTD5c7t7vFQVzGa0bg3Kd0BUDHc8FrvTtccYRB1KCi+u/N260UkD9sVLGRfU22+GiGE4Y/ZqdBROWDJ2ocwwmKehjNBL8KvON8uMwki/x+GXdevD8SJ6CN67E1CHhVTo2yaxRPeT6gwxcxgbHkSFkRPiEl+exLUlhXQ89JhfVf95PushGZM2R1csKeuxS4GIIaqMV0O3zqJFmpOWcqC2Z1wNFXMcD3MQMZa6yojGANkcMGY837OQRT1n34v2auQX6+PczAjcDd56hM4V7SgK2JH7v5BjfHngANka1JNRokcjnyPLgs8QAinqqmKG4ryJONj8XOA1nN6H0b+Y755zOP6Kd8thxZfDCwI9/9ouNi/aE4jM9GxyAY0mPse65rtARnAXm6XxsD27ap9o1P/9DseQPLAh6DBX52t69xPpiKloyZUbRxdSXz9qijqtxE7Q0Nja3JrKrElsnadTeby5P29H1iEiMMLW4bFCxnJcjUBU68SXxrZCZe0GOOJyTQwhwYmfDs3IWcT5D5iR/tnrB6AlmlCoIA6Gqe7nhHa1T8e4WaP6YtQpZszSIIwv30P2edGXG18uRiDojU6nnR7bYF88vqEjVpQvPBe50RRBZnU2TwjFWcyGqxsDpRDcWPaWIohiCdegk9D+FqW9lxoXGN+IvXRwWyJV1QwJK+gYRB6+UhfQpnlcoV9EbJ160PGbz1LhKmJSWvlAgvSZfSBNvtsSC/vfPKEkFlnXHYb6ofjlsLZ/lx17/+RrKDA9sQpGP27sCnjkWDaX4cozqR758v+TkZpqyrlT/nPZaFULSLFa0bKCwJzYY6h//fBIzCWZPATk2EPSWn4ZtcRO8egk+JG4/YfuaqlDKkdSCueJ6oTElMCMGCSqGSIb3DQEJFTEWBBQYFvWHYxSrWGxvA7+nhl7rQ+Zi2jAtMCEwCQYFKw4DAhoFAAQUAxRF0oXlW0b2aNbrU3wlEDgMZ4YECFOTPaIhLmMA"
eraa_peer_cert_pwd=""
eraa_ca_cert_b64="MIIDWzCCAkOgAwIBAgISAW6PqXNlW0tZl5XNXLWvj5kBMA0GCSqGSIb3DQEBBQUAMDYxJzAlBgNVBAMMHlNlcnZlciBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTELMAkGA1UEBhMCVVMwHhcNMTYxMjAyMjMwMDAwWhcNMjYxMjA0MjMwMDAwWjA2MScwJQYDVQQDDB5TZXJ2ZXIgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkxCzAJBgNVBAYTAlVTMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtLe7aqicStuZEIeCqq5tzk+RfxGwhpojx2UT7Hz4Y+JZDPDBbg/4qy4g769rn7HVpKE+RRg0YpLmAZGgWufeke73F4McsJ8zVLdxFTZ7Q+6GOsXBZ2hycUmAFvampL3fCtoFSBCQZrCNHi30IpWvQziXZ9TicRlxWgMrXn7F9qRHRZUbY5bhPJUkqxFaYeotWxteVUhpbKDkBfTxV+c799jGHwe81DYGAQ8Xvi7R/Y1SdL7LLHqFdgAYBOppZAr7exvqPGITtjrX75dJjj8d4KbfDpdBZQtTSYO8w5eltjAdxZ7aMNCBvx4JnpVdVE7B5AaU2n702BVIHloacMXr4QIDAQABo2MwYTAOBgNVHQ8BAf8EBAMCAQYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUW0OmIDWzfUHVdx5tWzrlSwaFo6kwHwYDVR0jBBgwFoAUW0OmIDWzfUHVdx5tWzrlSwaFo6kwDQYJKoZIhvcNAQEFBQADggEBACOlSmQ2Od7/76a5j9oJq+ZLaUCHWHit6W1FSsyzxTF9WlDZBQKPsQEMso4YyXjNx4q1GEe47fiBn3WxzuKSb2l1OTOmp6yMiBLJvezau5SHmeKWH8Y3ftzVlJS2Z18x96NWbloMdcf6iW9Zq9lYVt4mFejTcZdV9Dax49aiPsIsKvvCySzJsEHknbHLpOsCIOxXsPHoSdL4cOq/8KQn+Zrl0/bzpswK/a4/0lXsxS7ss7mhYx8XEtIW0lKtfUWLTd2Q5NtVtTauvjzjIGKlPNrHZXDv5E0fPYfhCgmWxxaf734agfJUZU1u6mQ0e1bzUZT/vKbP4pMIElO84jk0oPc="
eraa_product_uuid=""
eraa_initial_sg_token="MGZlYWM0M2UtM2Y1MS00YzNkLWE4YjUtMzY5ZDlmNGYwNzVl3rt1apVLRWOmUs5FISKmJDIppSPecUCwvGhwIlAqIpJz2Px197iqewOvpDpNT6W7udNZ3Q=="
eraa_policy_data=""

eraa_http_proxy_use="0"
eraa_http_proxy_hostname=""
eraa_http_proxy_port=""
eraa_http_proxy_user=""
eraa_http_proxy_password=""

arch=$(uname -m)
eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v7/7.1.503.0/agent_linux_i386.sh"
eraa_installer_checksum="4dbe6b1e64a5b9121ebb76df2be5acf0b32ad15f"

if $(echo "$arch" | grep -E "^(x86_64|amd64)$" 2>&1 > /dev/null)
then
    eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v7/7.1.503.0/agent_linux_x86_64.sh"
    eraa_installer_checksum="637ee450e422b20613cae5ddf8725c2012844601"
fi

echo "ESET Management Agent live installer script. Copyright © 1992-2019 ESET, spol. s r.o. - All rights reserved."

if test ! -z $eraa_server_company_name
then
  echo " * CompanyName: $eraa_server_company_name"
fi
echo " * Hostname: $eraa_server_hostname"
echo " * Port: $eraa_server_port"
echo " * Installer: $eraa_installer_url"
echo

if test -z $eraa_installer_url
then
  echo "No installer available for '$arch' arhitecture."
  exit 1
fi

local_cert_path="$(mktemp -q -u)"
echo $eraa_peer_cert_b64 | base64 -d > "$local_cert_path" && echo "$local_cert_path" >> "$cleanup_file"

if test -n "$eraa_ca_cert_b64"
then
  local_ca_path="$(mktemp -q -u)"
  echo $eraa_ca_cert_b64 | base64 -d > "$local_ca_path" && echo "$local_ca_path" >> "$cleanup_file"
fi

local_installer="$(mktemp -q -u)"

eraa_http_proxy_value=""

echo "Downloading ESET Management Agent installer..."

if test -n "$eraa_http_proxy_value"
then
  export use_proxy=yes
  export http_proxy="$eraa_http_proxy_value"
  (wget --connect-timeout 300 --no-check-certificate -O "$local_installer" "$eraa_installer_url" || wget --connect-timeout 300 --no-proxy --no-check-certificate -O "$local_installer" "$eraa_installer_url" || curl --fail --connect-timeout 300 -k "$eraa_installer_url" > "$local_installer") && echo "$local_installer" >> "$cleanup_file"
else
  (wget --connect-timeout 300 --no-check-certificate -O "$local_installer" "$eraa_installer_url" || curl --fail --connect-timeout 300 -k "$eraa_installer_url" > "$local_installer") && echo "$local_installer" >> "$cleanup_file"
fi

if test ! -s "$local_installer"
then
   echo "Failed to download installer file"
   exit 2
fi

echo -n "Checking integrity of installer script " && echo "$eraa_installer_checksum  $local_installer" | sha1sum -c

chmod +x "$local_installer"

local_migration_list="$(mktemp -q -u)"
tee "$local_migration_list" 2>&1 > /dev/null << __LOCAL_MIGRATION_LIST__

__LOCAL_MIGRATION_LIST__
test $? = 0 && echo "$local_migration_list" >> "$cleanup_file"

for dir in /sys/class/net/*/
do
    if test -f "$dir/address"
    then
        grep -E '00:00:00:00:00:00' "$dir/address" > /dev/null || macs="$macs $(sed 's/\://g' "$dir/address" | awk '{print toupper($0)}')"
    fi
done

while read line
do
    if test -n "$macs" -a -n "$line"
    then
        mac=$(echo $line | awk '{print $1}')
        uuid=$(echo $line | awk '{print $2}')
        lsid=$(echo $line | awk '{print $3}')
        if $(echo "$macs" | grep "$mac" > /dev/null)
        then
            if test -n "$mac" -a -n "$uuid" -a -n "$lsid"
            then
                additional_params="--product-guid $uuid --log-sequence-id $lsid"
                break
            fi
        fi
    fi
done < "$local_migration_list"

command -v sudo > /dev/null && usesudo="sudo -E" || usesudo=""

export _ERAAGENT_PEER_CERT_PASSWORD="$eraa_peer_cert_pwd"

echo
echo Running installer script $local_installer
echo

$usesudo /bin/sh "$local_installer"\
   --skip-license \
   --hostname "$eraa_server_hostname"\
   --port "$eraa_server_port"\
   --cert-path "$local_cert_path"\
   --cert-password "env:_ERAAGENT_PEER_CERT_PASSWORD"\
   --cert-password-is-base64\
   --initial-static-group "$eraa_initial_sg_token"\
   $(test "$eraa_http_proxy_use" = "1" && echo --proxy-hostname "$eraa_http_proxy_hostname" --proxy-port "$eraa_http_proxy_port" --proxy-user "$eraa_http_proxy_user" --proxy-password "$eraa_http_proxy_password")\
   --enable-imp-program\
   $(test -n "$local_ca_path" && echo --cert-auth-path "$local_ca_path")\
   $(test -n "$eraa_product_uuid" && echo --product-guid "$eraa_product_uuid")\
   $(test -n "$eraa_policy_data" && echo --custom-policy "$eraa_policy_data")\
   $additional_params
